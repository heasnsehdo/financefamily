When project is updated significantly
- Check if README.md in trickle/notes needs to be updated
- Update feature list if new features are added
- Update structure information if new pages are created
- Update documentation if workflows or processes change
- Keep README.md concise and focused on essential information